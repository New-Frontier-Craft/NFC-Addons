// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;

// Referenced classes of package net.minecraft.src:
//            TextureFX, ModLoader

public class ModTextureAnimation extends TextureFX
{

    public ModTextureAnimation(int i, int j, BufferedImage bufferedimage, int k)
    {
        this(i, 1, j, bufferedimage, k);
    }

    public ModTextureAnimation(int i, int j, int k, BufferedImage bufferedimage, int l)
    {
        super(i);
        index = 0;
        ticks = 0;
        tileSize = j;
        tileImage = k;
        tickRate = l;
        ticks = l;
        bindImage(ModLoader.getMinecraftInstance().renderEngine);
        //int i1 = GL11.glGetTexLevelParameteri(3553 /*GL_TEXTURE_2D*/, 0, 4096 /*GL_TEXTURE_WIDTH*/) / 16;
        //int j1 = GL11.glGetTexLevelParameteri(3553 /*GL_TEXTURE_2D*/, 0, 4097 /*GL_TEXTURE_HEIGHT*/) / 16;
        //int k1 = bufferedimage.getWidth();
        //int l1 = bufferedimage.getHeight();
        int i2 = (int)Math.floor(res / res);
        if(i2 <= 0)
        {
            throw new IllegalArgumentException("source has no complete images");
        }
        images = new byte[i2][];
        if(bufferedimage.getWidth() != res)
        {
            BufferedImage bufferedimage1 = new BufferedImage(res, res * i2, 6);
            Graphics2D graphics2d = bufferedimage1.createGraphics();
            graphics2d.drawImage(bufferedimage, 0, 0, res, res * i2, 0, 0, res, res, null);
            graphics2d.dispose();
            bufferedimage = bufferedimage1;
        }
        for(int j2 = 0; j2 < i2; j2++)
        {
            int ai[] = new int[res * res];
            bufferedimage.getRGB(0, res * j2, res, res, ai, 0, res);
            images[j2] = new byte[res * res * 4];
            for(int k2 = 0; k2 < ai.length; k2++)
            {
                int l2 = ai[k2] >> 24 & 0xff;
                int i3 = ai[k2] >> 16 & 0xff;
                int j3 = ai[k2] >> 8 & 0xff;
                int k3 = ai[k2] >> 0 & 0xff;
                images[j2][k2 * 4 + 0] = (byte)i3;
                images[j2][k2 * 4 + 1] = (byte)j3;
                images[j2][k2 * 4 + 2] = (byte)k3;
                images[j2][k2 * 4 + 3] = (byte)l2;
            }

        }
        res = bufferedimage.getWidth();

    }

    public void onTick()
    {
        if(ticks >= tickRate)
        {
            index++;
            if(index >= images.length)
            {
                index = 0;
            }
            imageData = images[index];
            ticks = 0;
        }
        ticks++;
    }

    private final int tickRate;
    private final byte images[][];
    private int index;
    private int ticks;
}
