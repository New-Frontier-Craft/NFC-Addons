// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;


// Referenced classes of package net.minecraft.src:
//            Block, Material

public class BlockCloth extends Block
{

    public BlockCloth()
    {
        super(35, 64, Material.cloth);
    }

//    public int getBlockTextureFromSideAndMetadata(int i, int j)
//    {
//        if(j == 0)
//        {
//            return blockIndexInTexture;
//        } else
//        {
//            j = ~(j & 0xf);
//            return 113 + ((j & 8) >> 3) + (j & 7) * 16;
//        }
//    }
    
    protected int damageDropped(int i)
    {
        return i;
    }

    public static int func_21034_c(int i)
    {
        return ~i & 0xf;
    }

    public static int func_21035_d(int i)
    {
        return ~i & 0xf;
    }
    
    /**ModLoaderNFC Render Code**/
	public int getRenderColor(int i) {
		return ColorizerCustom.getCustomColor(i & 15, 0);
	}
	
    public int colorMultiplier(IBlockAccess iblockaccess, int i, int j, int k)
    {
    	int l = iblockaccess.getBlockMetadata(i, j, k);
    	return getRenderColor(l);
    }
}
