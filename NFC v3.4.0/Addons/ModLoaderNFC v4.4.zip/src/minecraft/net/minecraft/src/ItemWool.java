package net.minecraft.src;

public class ItemWool extends ItemBlock {

	public ItemWool(int i) {
		super(i);
		setMaxDamage(0);
		setHasSubtypes(true);
	}
	
	public int getIconFromDamage(int i) {
		return Block.cloth.getBlockTextureFromSideAndMetadata(2, i);
	}

	public int getPlacedBlockMetadata(int i) {
		return i;
	}

	public String getItemNameIS(ItemStack itemstack) {
		String j = dyeColors[BlockCloth.func_21034_c(itemstack.getItemDamage() % dyeColors.length)];
		
		return (new StringBuilder()).append("tile.cloth.").append(j).toString();
	}

	public static final String dyeColors[] = { "black", "red", "green",
			"brown", "blue", "purple", "cyan", "silver", "gray", "pink",
			"lime", "yellow", "lightBlue", "magenta", "orange", "white" };
	
}
