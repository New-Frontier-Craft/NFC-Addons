Removes the artificially hidden blocks and gives access to all NFC ids, excluding the secret discs

If you'd like to remove the ID + Metadata display from tooltips, delete the id.class (GuiContainer) file before installing the mod