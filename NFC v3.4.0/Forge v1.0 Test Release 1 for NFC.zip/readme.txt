Ported and reworked for use with NFC by ChessChicken-KZ
Based on Reforged by Meefy and Kleadron
Based on Forge 1.0.6 by Eloraam, SpaceToad, and Flowerchild

Requires ModLoaderNFC v4.3