Edits RenderPlayer, EntityRenderer, EntityPlayer, EntityPlayerSP, EntityOtherPlayMP, and EntityLiving

Turns your player into a fox! Changes the player to be only one block tall to match, letting you slip through smaller openings and the like. Also, blocks, items, and tools are held in the mouth of the fox, as it'd be silly for a fox to hold a tool in its paw