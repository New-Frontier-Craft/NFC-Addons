To port to other versions or mods, copy all the code under the "Torch Slab" comments, 
which you should be able to find by doing a word search for that word combination.