Version History
=====================================
Classic Fusion Pack v1: 
Original Release

------------------

Classic Fusion Pack v2: 
Changed cobblestone/piston/dispenser & workbench textures to 
match relative blocks they're made out of. 
Added classic cobblestone to pack. 
Saturation on logs increased. 
Added background texture of classic planks
Sandstone now matches sand shading

------------------

Classic Fusion Pack v2.1:
Updated to be compatible with 1.8.7_0X

------------------

Classic Fusion Pack v2.2:
Updated to be compatible with v3.4.X