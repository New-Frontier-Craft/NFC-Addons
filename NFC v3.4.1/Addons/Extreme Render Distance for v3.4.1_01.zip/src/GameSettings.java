// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import java.io.*;
import java.net.URL;

import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;

// Referenced classes of package net.minecraft.src:
//            KeyBinding, StringTranslate, EnumOptions, SoundManager, 
//            RenderGlobal, RenderEngine, EnumOptionsMappingHelper, StatCollector

public class GameSettings
{

    public GameSettings(Minecraft minecraft, File file)
    {
        musicVolume = 1.0F;
        soundVolume = 1.0F;
        mouseSensitivity = 0.5F;
        invertMouse = false;
        renderDistance = 0;
        viewBobbing = true;
        anaglyph = false;
        advancedOpengl = false;
        limitFramerate = 1;
        fancyGraphics = true;
        ambientOcclusion = true;
        skin = "Default";
        keyBindForward = new KeyBinding("key.forward", 17);
        keyBindLeft = new KeyBinding("key.left", 30);
        keyBindBack = new KeyBinding("key.back", 31);
        keyBindRight = new KeyBinding("key.right", 32);
        keyBindJump = new KeyBinding("key.jump", 57);
        keyBindInventory = new KeyBinding("key.inventory", 18);
        keyBindDrop = new KeyBinding("key.drop", 16);
        keyBindChat = new KeyBinding("key.chat", 20);
        keyBindToggleFog = new KeyBinding("key.fog", 33);
        keyBindSneak = new KeyBinding("key.sneak", 42);
        keyBindings = (new KeyBinding[] {
            keyBindForward, keyBindLeft, keyBindBack, keyBindRight, keyBindJump, keyBindSneak, keyBindDrop, keyBindInventory, keyBindChat, keyBindToggleFog
        });
        difficulty = 2;
        hideGUI = false;
        thirdPersonView = false;
        thirdPersonView2 = false;
        showDebugInfo = false;
        lastServer = "";
        field_22275_C = false;
        smoothCamera = false;
        field_22273_E = false;
        field_22272_F = 1.0F;
        field_22271_G = 1.0F;
        guiScale = 0;
        mc = minecraft;
        renderItemsIn3D = true;
        cloudHeight = 0.55F;
        renderAdventureTrees = false;
        ignoreJavaWarning = false;
        validOutline = 0;
        invalidOutline = 2;
        fovEffects = 1;
        distortionEffects = 1;
        chatBG = 0.5F;
        tooltipBG = 0;
        heldTooltips = true;
        outlineOpacity = 0.4F;
        optionsFile = new File(file, "NFCoptions.txt");
        loadOptions();
    }

    public GameSettings()
    {
        musicVolume = 1.0F;
        soundVolume = 1.0F;
        mouseSensitivity = 0.5F;
        invertMouse = false;
        renderDistance = 0;
        viewBobbing = true;
        anaglyph = false;
        advancedOpengl = false;
        limitFramerate = 1;
        fancyGraphics = true;
        ambientOcclusion = true;
        skin = "Default";
        keyBindForward = new KeyBinding("key.forward", 17);
        keyBindLeft = new KeyBinding("key.left", 30);
        keyBindBack = new KeyBinding("key.back", 31);
        keyBindRight = new KeyBinding("key.right", 32);
        keyBindJump = new KeyBinding("key.jump", 57);
        keyBindInventory = new KeyBinding("key.inventory", 18);
        keyBindDrop = new KeyBinding("key.drop", 16);
        keyBindChat = new KeyBinding("key.chat", 20);
        keyBindToggleFog = new KeyBinding("key.fog", 33);
        keyBindSneak = new KeyBinding("key.sneak", 42);
        keyBindings = (new KeyBinding[] {
            keyBindForward, keyBindLeft, keyBindBack, keyBindRight, keyBindJump, keyBindSneak, keyBindDrop, keyBindInventory, keyBindChat, keyBindToggleFog
        });
        difficulty = 2;
        hideGUI = false;
        thirdPersonView = false;
        thirdPersonView2 = false;
        showDebugInfo = false;
        lastServer = "";
        field_22275_C = false;
        smoothCamera = false;
        field_22273_E = false;
        field_22272_F = 1.0F;
        field_22271_G = 1.0F;
        guiScale = 0;
        renderItemsIn3D = true;
        renderAdventureTrees = false;
        ignoreJavaWarning = false;
        validOutline = 0;
        invalidOutline = 2;
        fovEffects = 1;
        distortionEffects = 1;
        chatBG = 0.5F;
        tooltipBG = 0;
        heldTooltips = true;
        outlineOpacity = 0.4F;
    }

    public String getKeyBindingDescription(int i)
    {
        StringTranslate stringtranslate = StringTranslate.getInstance();
        return stringtranslate.translateKey(keyBindings[i].keyDescription);
    }

    public String getOptionDisplayString(int i)
    {
        return Keyboard.getKeyName(keyBindings[i].keyCode);
    }

    public void setKeyBinding(int i, int j)
    {
    	int k = j != 1 ? j : 0;
        keyBindings[i].keyCode = k;
        saveOptions();
    }

    public void setOptionFloatValue(EnumOptions enumoptions, float f)
    {
        if(enumoptions == EnumOptions.MUSIC)
        {
            musicVolume = f;
            mc.sndManager.onSoundOptionsChanged();
        }
        if(enumoptions == EnumOptions.SOUND)
        {
            soundVolume = f;
            mc.sndManager.onSoundOptionsChanged();
        }
        if(enumoptions == EnumOptions.SENSITIVITY)
        {
            mouseSensitivity = f;
        }
        if(enumoptions == EnumOptions.FOV)
        {
            fov = f;
        }
        if(enumoptions == EnumOptions.CLOUD_HEIGHT)
        {
            cloudHeight = f;
        }
        if(enumoptions == EnumOptions.DISTORTION_EFFECTS) {
        	distortionEffects = f;
        }
        if(enumoptions == EnumOptions.FOV_EFFECTS) {
        	fovEffects = f;
        }
        if(enumoptions == EnumOptions.CHAT_BACKGROUND) {
        	chatBG = f;
        }
        if(enumoptions == EnumOptions.TOOLTIP_BACKGROUND) {
        	tooltipBG = f;
        }
        if(enumoptions == EnumOptions.OUTLINE_OPACITY) {
        	outlineOpacity = f;
        }
    }

    public void setOptionValue(EnumOptions enumoptions, int i)
    {
        if(enumoptions == EnumOptions.INVERT_MOUSE)
        {
            invertMouse = !invertMouse;
        }
        if(enumoptions == EnumOptions.RENDER_DISTANCE)
        {
            renderDistance = (renderDistance + i) % 5;
        }
        if(enumoptions == EnumOptions.GUI_SCALE)
        {
            guiScale = guiScale + i & 3;
        }
        if(enumoptions == EnumOptions.VIEW_BOBBING)
        {
            viewBobbing = !viewBobbing;
        }
        if(enumoptions == EnumOptions.ADVANCED_OPENGL)
        {
            advancedOpengl = !advancedOpengl;
            mc.renderGlobal.loadRenderers();
        }
        if(enumoptions == EnumOptions.ANAGLYPH)
        {
            anaglyph = !anaglyph;
            mc.renderEngine.refreshTextures();
        }
        if(enumoptions == EnumOptions.FRAMERATE_LIMIT)
        {
            limitFramerate = (limitFramerate + i + 3) % 3;
        }
        if(enumoptions == EnumOptions.DIFFICULTY)
        {
            difficulty = difficulty + i & 3;
        }
        if(enumoptions == EnumOptions.GRAPHICS)
        {
            fancyGraphics = !fancyGraphics;
            mc.renderGlobal.loadRenderers();
        }
        if(enumoptions == EnumOptions.AMBIENT_OCCLUSION)
        {
            ambientOcclusion = !ambientOcclusion;
            mc.renderGlobal.loadRenderers();
        }
        if(enumoptions == EnumOptions.FANCY_ITEMS)
        {
            renderItemsIn3D = !renderItemsIn3D;
        }
        if(enumoptions == EnumOptions.ADVENTURE_TREES)
        {
            renderAdventureTrees = !renderAdventureTrees;
            mc.renderGlobal.loadRenderers();
        }
        if(enumoptions == EnumOptions.VALID_OUTLINE) {
        	validOutline = (validOutline + i) % 6;
        }
        if(enumoptions == EnumOptions.INVALID_OUTLINE) {
        	invalidOutline = (invalidOutline + i) % 6;
        }
        if(enumoptions == EnumOptions.ITEM_TOOLTIPS) {
        	heldTooltips = !heldTooltips;
        }
        saveOptions();
    }

    public float getOptionFloatValue(EnumOptions enumoptions)
    {
        if(enumoptions == EnumOptions.MUSIC)
        {
            return musicVolume;
        }
        if(enumoptions == EnumOptions.SOUND)
        {
            return soundVolume;
        }
        if(enumoptions == EnumOptions.SENSITIVITY)
        {
            return mouseSensitivity;
        }
        if(enumoptions == EnumOptions.FOV)
        {
            return fov;
        }
        if(enumoptions == EnumOptions.CLOUD_HEIGHT)
        {
            return cloudHeight;
        }
        if(enumoptions == EnumOptions.DISTORTION_EFFECTS) {
        	return distortionEffects;
        }
        if(enumoptions == EnumOptions.FOV_EFFECTS) {
        	return fovEffects;
        }
        if(enumoptions == EnumOptions.CHAT_BACKGROUND) {
        	return chatBG;
        }
        if(enumoptions == EnumOptions.TOOLTIP_BACKGROUND) {
        	return tooltipBG;
        }
        if(enumoptions == EnumOptions.OUTLINE_OPACITY) {
        	return outlineOpacity;
        }
        return 0.0F;
    }

    public boolean getOptionOrdinalValue(EnumOptions enumoptions)
    {
        switch(EnumOptionsMappingHelper.enumOptionsMappingHelperArray[enumoptions.ordinal()])
        {
        case 1: // '\001'
            return invertMouse;

        case 2: // '\002'
            return viewBobbing;

        case 3: // '\003'
            return anaglyph;

        case 4: // '\004'
            return advancedOpengl;

        case 5: // '\005'
            return ambientOcclusion;
            
        case 14: // '\002'
            return renderItemsIn3D;
        
        case 16:
        	return renderAdventureTrees;
        	
        case 21:
        	return heldTooltips;
        }
        return false;
    }

    public String getKeyBinding(EnumOptions enumoptions)
    {
        StringTranslate stringtranslate = StringTranslate.getInstance();
        String s = (new StringBuilder()).append(stringtranslate.translateKey(enumoptions.getEnumString())).append(": ").toString();
        if(enumoptions.getEnumFloat())
        {
            float f = getOptionFloatValue(enumoptions);
            if(enumoptions == EnumOptions.FOV){
            	if(f == 0.0F)
                {
                    return stringtranslate.translateKey("options.fov") + ": " + stringtranslate.translateKey("options.fov.normal");
                } else if(f == 1.0F) {
                	return stringtranslate.translateKey("options.fov") + ": " + stringtranslate.translateKey("options.fov.max");
                } else {
                	return stringtranslate.translateKey("options.fov") + ": " + ((int)(f*30F+70));
                }
            }
            if(enumoptions == EnumOptions.CLOUD_HEIGHT){
            	if((int)(f*40F) == 0)
                {
                    return stringtranslate.translateKey("options.cloudHeight") + ": " + stringtranslate.translateKey("options.cloudHeight.old");
                } else if ((int)(f*40F) == 22){
                	return stringtranslate.translateKey("options.cloudHeight") + ": " + stringtranslate.translateKey("options.cloudHeight.default");
                } else {
                	return stringtranslate.translateKey("options.cloudHeight") + ": +" + ((int)(f*40F));
                }
            }
            if(enumoptions == EnumOptions.SENSITIVITY)
            {
                if(f == 0.0F)
                {
                    return (new StringBuilder()).append(s).append(stringtranslate.translateKey("options.sensitivity.min")).toString();
                }
                if(f == 1.0F)
                {
                    return (new StringBuilder()).append(s).append(stringtranslate.translateKey("options.sensitivity.max")).toString();
                } else
                {
                    return (new StringBuilder()).append(s).append((int)(f * 200F)).append("%").toString();
                }
            }
            if(f == 0.0F)
            {
                return (new StringBuilder()).append(s).append(stringtranslate.translateKey("options.off")).toString();
            } else
            {
                return (new StringBuilder()).append(s).append((int)(f * 100F)).append("%").toString();
            }
        }
        if(enumoptions.getEnumBoolean())
        {
            boolean flag = getOptionOrdinalValue(enumoptions);
            if(flag)
            {
                return (new StringBuilder()).append(s).append(stringtranslate.translateKey("options.on")).toString();
            } else
            {
                return (new StringBuilder()).append(s).append(stringtranslate.translateKey("options.off")).toString();
            }
        }
        if(enumoptions == EnumOptions.RENDER_DISTANCE)
        {
            return (new StringBuilder()).append(s).append(stringtranslate.translateKey(RENDER_DISTANCES[renderDistance])).toString();
        }
        if(enumoptions == EnumOptions.DIFFICULTY)
        {
            return (new StringBuilder()).append(s).append(stringtranslate.translateKey(DIFFICULTIES[difficulty])).toString();
        }
        if(enumoptions == EnumOptions.GUI_SCALE)
        {
            return (new StringBuilder()).append(s).append(stringtranslate.translateKey(GUISCALES[guiScale])).toString();
        }
        if(enumoptions == EnumOptions.FRAMERATE_LIMIT)
        {
            return (new StringBuilder()).append(s).append(StatCollector.translateToLocal(LIMIT_FRAMERATES[limitFramerate])).toString();
        }
        if(enumoptions == EnumOptions.VALID_OUTLINE || enumoptions == EnumOptions.INVALID_OUTLINE) {
            return (new StringBuilder()).append(s).append(StatCollector.translateToLocal(OUTLINE_COLORS[enumoptions == EnumOptions.VALID_OUTLINE ? validOutline : invalidOutline])).toString();
        }
        if(enumoptions == EnumOptions.GRAPHICS)
        {
            if(fancyGraphics)
            {
                return (new StringBuilder()).append(s).append(stringtranslate.translateKey("options.graphics.fancy")).toString();
            } else
            {
                return (new StringBuilder()).append(s).append(stringtranslate.translateKey("options.graphics.fast")).toString();
            }
        } else
        {
            return s;
        }
    }

    public void loadOptions()
    {
        try
        {
            if(!optionsFile.exists())
            {
                return;
            }
            BufferedReader bufferedreader = new BufferedReader(new FileReader(optionsFile));
            for(String s = ""; (s = bufferedreader.readLine()) != null;)
            {
                try
                {
                    String as[] = s.split(":");
                    if(as[0].equals("music"))
                    {
                        musicVolume = parseFloat(as[1]);
                    }
                    if(as[0].equals("sound"))
                    {
                        soundVolume = parseFloat(as[1]);
                    }
                    if(as[0].equals("mouseSensitivity"))
                    {
                        mouseSensitivity = parseFloat(as[1]);
                    }
                    if(as[0].equals("invertYMouse"))
                    {
                        invertMouse = as[1].equals("true");
                    }
                    if(as[0].equals("viewDistance"))
                    {
                        renderDistance = Integer.parseInt(as[1]);
                    }
                    if(as[0].equals("guiScale"))
                    {
                        guiScale = Integer.parseInt(as[1]);
                    }
                    if(as[0].equals("bobView"))
                    {
                        viewBobbing = as[1].equals("true");
                    }
                    if(as[0].equals("anaglyph3d"))
                    {
                        anaglyph = as[1].equals("true");
                    }
                    if(as[0].equals("advancedOpengl"))
                    {
                        advancedOpengl = as[1].equals("true");
                    }
                    if(as[0].equals("fpsLimit"))
                    {
                        limitFramerate = Integer.parseInt(as[1]);
                    }
                    if(as[0].equals("difficulty"))
                    {
                        difficulty = Integer.parseInt(as[1]);
                    }
                    if(as[0].equals("fancyGraphics"))
                    {
                        fancyGraphics = as[1].equals("true");
                    }
                    if(as[0].equals("ao"))
                    {
                        ambientOcclusion = as[1].equals("true");
                    }
                    if(as[0].equals("skin"))
                    {
                        skin = as[1];
                    }
                    if(as[0].equals("lastServer") && as.length >= 2)
                    {
                        lastServer = as[1];
                    }
                    if(as[0].equals("fov"))
                    {
                        fov = parseFloat(as[1]);
                    }
                    if(as[0].equals("cloudHeight"))
                    {
                        cloudHeight = parseFloat(as[1]);
                    }
                    if(as[0].equals("3dItems"))
                    {
                        renderItemsIn3D = as[1].equals("true");
                    }
                    if(as[0].equals("adventureTrees"))
                    {
                    	renderAdventureTrees = as[1].equals("true");
                    }
                    if(as[0].equals("ignoreJavaWarning"))
                    {
                    	ignoreJavaWarning = as[1].equals("true");
                    }
                    if(as[0].equals("validOutline"))
                    {
                    	validOutline = Integer.parseInt(as[1]);
                    }
                    if(as[0].equals("invalidOutline"))
                    {
                    	invalidOutline = Integer.parseInt(as[1]);
                    }
                    if(as[0].equals("distortionEffects"))
                    {
                        distortionEffects = parseFloat(as[1]);
                    }
                    if(as[0].equals("fovEffects"))
                    {
                        fovEffects = parseFloat(as[1]);
                    }
                    if(as[0].equals("heldTooltips"))
                    {
                        heldTooltips = as[1].equals("true");
                    }
                    if(as[0].equals("chatBG"))
                    {
                        chatBG = parseFloat(as[1]);
                    }
                    if(as[0].equals("tooltipBG"))
                    {
                        tooltipBG = parseFloat(as[1]);
                    }
                    if(as[0].equals("outlineOpacity"))
                    {
                        outlineOpacity = parseFloat(as[1]);
                    }
                    int i = 0;
                    while(i < keyBindings.length) 
                    {
                        if(as[0].equals((new StringBuilder()).append("key_").append(keyBindings[i].keyDescription).toString()))
                        {
                            keyBindings[i].keyCode = Integer.parseInt(as[1]);
                        }
                        i++;
                    }
                }
                catch(Exception exception1)
                {
                    System.out.println((new StringBuilder()).append("Skipping bad option: ").append(s).toString());
                }
            }

            bufferedreader.close();
        }
        catch(Exception exception)
        {
            System.out.println("Failed to load options");
            exception.printStackTrace();
        }
    }

    private float parseFloat(String s)
    {
        if(s.equals("true"))
        {
            return 1.0F;
        }
        if(s.equals("false"))
        {
            return 0.0F;
        } else
        {
            return Float.parseFloat(s);
        }
    }

    public void saveOptions()
    {
        try
        {
            PrintWriter printwriter = new PrintWriter(new FileWriter(optionsFile));
            printwriter.println((new StringBuilder()).append("music:").append(musicVolume).toString());
            printwriter.println((new StringBuilder()).append("sound:").append(soundVolume).toString());
            printwriter.println((new StringBuilder()).append("invertYMouse:").append(invertMouse).toString());
            printwriter.println((new StringBuilder()).append("mouseSensitivity:").append(mouseSensitivity).toString());
            printwriter.println((new StringBuilder()).append("viewDistance:").append(renderDistance).toString());
            printwriter.println((new StringBuilder()).append("guiScale:").append(guiScale).toString());
            printwriter.println((new StringBuilder()).append("bobView:").append(viewBobbing).toString());
            printwriter.println((new StringBuilder()).append("anaglyph3d:").append(anaglyph).toString());
            printwriter.println((new StringBuilder()).append("advancedOpengl:").append(advancedOpengl).toString());
            printwriter.println((new StringBuilder()).append("fpsLimit:").append(limitFramerate).toString());
            printwriter.println((new StringBuilder()).append("difficulty:").append(difficulty).toString());
            printwriter.println((new StringBuilder()).append("fancyGraphics:").append(fancyGraphics).toString());
            printwriter.println((new StringBuilder()).append("ao:").append(ambientOcclusion).toString());
            printwriter.println((new StringBuilder()).append("skin:").append(skin).toString());
            printwriter.println((new StringBuilder()).append("lastServer:").append(lastServer).toString());
            printwriter.println((new StringBuilder()).append("fov:").append(fov).toString());
            printwriter.println((new StringBuilder()).append("3dItems:").append(renderItemsIn3D).toString());
            printwriter.println((new StringBuilder()).append("cloudHeight:").append(cloudHeight).toString());
            printwriter.println((new StringBuilder()).append("adventureTrees:").append(renderAdventureTrees).toString());
            printwriter.println((new StringBuilder()).append("langFile:").append(StringTranslate.langFile).toString());
            printwriter.println((new StringBuilder()).append("ignoreJavaWarning:").append(ignoreJavaWarning).toString());
            printwriter.println((new StringBuilder()).append("validOutline:").append(validOutline).toString());
            printwriter.println((new StringBuilder()).append("invalidOutline:").append(invalidOutline).toString());
            printwriter.println((new StringBuilder()).append("fovEffects:").append(fovEffects).toString());
            printwriter.println((new StringBuilder()).append("distortionEffects:").append(distortionEffects).toString());
            printwriter.println((new StringBuilder()).append("heldTooltips:").append(heldTooltips).toString());
            printwriter.println((new StringBuilder()).append("chatBG:").append(chatBG).toString());
            printwriter.println((new StringBuilder()).append("tooltipBG:").append(tooltipBG).toString());
            printwriter.println((new StringBuilder()).append("outlineOpacity:").append(outlineOpacity).toString());
            for(int i = 0; i < keyBindings.length; i++)
            {
                printwriter.println((new StringBuilder()).append("key_").append(keyBindings[i].keyDescription).append(":").append(keyBindings[i].keyCode).toString());
            }

            printwriter.close();
        }
        catch(Exception exception)
        {
            System.out.println("Failed to save options");
            exception.printStackTrace();
        }
    }

    private static final String RENDER_DISTANCES[] = {
        "options.renderDistance.extreme", "options.renderDistance.far", "options.renderDistance.normal", "options.renderDistance.short", "options.renderDistance.tiny"
    };
    private static final String DIFFICULTIES[] = {
        "options.difficulty.peaceful", "options.difficulty.easy", "options.difficulty.normal", "options.difficulty.hard"
    };
    private static final String GUISCALES[] = {
        "options.guiScale.auto", "options.guiScale.small", "options.guiScale.normal", "options.guiScale.large"
    };
    private static final String LIMIT_FRAMERATES[] = {
        "performance.max", "performance.balanced", "performance.powersaver"
    };
    private static final String OUTLINE_COLORS[] = {
    	"accessibility.outlines.color.black", "accessibility.outlines.color.white", "accessibility.outlines.color.red", "accessibility.outlines.color.green", "accessibility.outlines.color.blue", "accessibility.outlines.color.rainbow"
    };
    public float musicVolume;
    public float soundVolume;
    public float mouseSensitivity;
    public boolean invertMouse;
    public int renderDistance;
    public boolean viewBobbing;
    public boolean anaglyph;
    public boolean advancedOpengl;
    public int limitFramerate;
    public boolean fancyGraphics;
    public boolean ambientOcclusion;
    public String skin;
    public KeyBinding keyBindForward;
    public KeyBinding keyBindLeft;
    public KeyBinding keyBindBack;
    public KeyBinding keyBindRight;
    public KeyBinding keyBindJump;
    public KeyBinding keyBindInventory;
    public KeyBinding keyBindDrop;
    public KeyBinding keyBindChat;
    public KeyBinding keyBindToggleFog;
    public KeyBinding keyBindSneak;
    public KeyBinding keyBindings[];
    protected Minecraft mc;
    public boolean renderItemsIn3D;
    public boolean renderAdventureTrees;
    private File optionsFile;
    public int difficulty;
    public boolean hideGUI;
    public boolean thirdPersonView;
    public boolean thirdPersonView2;
    public boolean showDebugInfo;
    public String lastServer;
    public boolean field_22275_C;
    public boolean smoothCamera;
    public boolean field_22273_E;
    public float field_22272_F;
    public float field_22271_G;
    public float fov;
    public float cloudHeight;
    public int guiScale;
    public boolean ignoreJavaWarning;
    public int validOutline;
    public int invalidOutline;
    public float distortionEffects;
    public float fovEffects;
    public float chatBG;
    public float tooltipBG;
    public boolean heldTooltips;
    public float outlineOpacity;

}
