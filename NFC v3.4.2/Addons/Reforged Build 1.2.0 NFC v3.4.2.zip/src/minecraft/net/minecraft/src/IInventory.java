// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;


// Referenced classes of package net.minecraft.src:
//            ItemStack, EntityPlayer

public interface IInventory
{

    abstract int getSizeInventory();

    abstract ItemStack getStackInSlot(int i);

    abstract ItemStack decrStackSize(int i, int j);

    abstract void setInventorySlotContents(int i, ItemStack itemstack);

    abstract String getInvName();

    abstract int getInventoryStackLimit();

    abstract void onInventoryChanged();

    abstract boolean canInteractWith(EntityPlayer entityplayer);
}
