package net.minecraft.src;

/**
 * DUMMY CLASS
 */
public class Loc {
    public Loc(int i, int j, int k)
    {

    }

}
