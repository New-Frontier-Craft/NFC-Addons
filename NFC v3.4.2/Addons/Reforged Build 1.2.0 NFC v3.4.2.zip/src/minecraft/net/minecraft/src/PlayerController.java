// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.src.forge.ForgeHooks;
import net.minecraft.src.forge.IUseItemFirst;

// Referenced classes of package net.minecraft.src:
//            World, Block, ItemStack, EntityPlayer, 
//            InventoryPlayer, EntityPlayerSP, WorldProvider, Container, 
//            Entity

public class PlayerController {

	public PlayerController(Minecraft minecraft) {
		isInTestMode = false;
		mc = minecraft;
	}
	
	public void func_717_a(World world) {
	}

	public void clickBlock(int i, int j, int k, int l) {
		if(!isInTestMode) {
			mc.theWorld.onBlockHit(mc.thePlayer, i, j, k, l);
			sendBlockRemoved(i, j, k, l);
		}
	}

	public boolean sendBlockRemoved(int i, int j, int k, int l) {
		World world = mc.theWorld;
		Block block = Block.blocksList[world.getBlockId(i, j, k)];
        if(block == null)
        {
            return false;
        }
		world.func_28106_e(2001, i, j, k,
				block.blockID + world.getBlockMetadata(i, j, k) * 256);
		int i1 = world.getBlockMetadata(i, j, k);
		boolean flag = world.setBlockWithNotify(i, j, k, 0);
		if (flag) {
			block.onBlockDestroyedByPlayer(world, i, j, k, i1);
		}
		return flag;
	}

	public void sendBlockRemoving(int i, int j, int k, int l) {
	}

	public void resetBlockRemoving() {
	}

	public void setPartialTime(float f) {
	}

	public float getBlockReachDistance() {
		return 5F;
	}

	public boolean sendUseItem(EntityPlayer entityplayer, World world,
			ItemStack itemstack) {
		int i = itemstack.stackSize;
		ItemStack itemstack1 = itemstack.useItemRightClick(world, entityplayer);
		if (itemstack1 != itemstack || itemstack1 != null
				&& itemstack1.stackSize != i) {
			entityplayer.inventory.mainInventory[entityplayer.inventory.currentItem] = itemstack1;
			if (itemstack1.stackSize == 0) {
				entityplayer.inventory.mainInventory[entityplayer.inventory.currentItem] = null;
				ForgeHooks.onDestroyCurrentItem(entityplayer,itemstack1);
			}
			return true;
		} else {
			return false;
		}
	}

	public void flipPlayer(EntityPlayer entityplayer) {
	}

	public void updateController() {
	}

	public boolean shouldDrawHUD() {
		return true;
	}

	public void func_6473_b(EntityPlayer entityplayer) {
	}

	public boolean sendPlaceBlock(EntityPlayer entityplayer, World world,
			ItemStack itemstack, int i, int j, int k, int l) {

		if (itemstack != null && itemstack.getItem() instanceof IUseItemFirst) {
			IUseItemFirst iuif = (IUseItemFirst) itemstack.getItem();
			if (iuif.onItemUseFirst(itemstack, entityplayer, world, i, j, k, l)) {
				return true;
			}
		}

		boolean sneak = entityplayer.isSneaking();
		int i1 = world.getBlockId(i, j, k);
		
		if (sneak && itemstack != null) {
			if (itemstack.useItem(entityplayer, world, i, j, k, l)) {
				return true;
			}
			return i1 > 0 && Block.blocksList[i1].blockActivated(world, i, j, k, entityplayer);
		} else
			if (i1 > 0 && Block.blocksList[i1].blockActivated(world, i, j, k, entityplayer)) {
				return true;
		} else
			if (itemstack == null) {
				return false;
			} else {
				if(!itemstack.useItem(entityplayer, world, i, j, k, l))
					return false;
				if(itemstack.stackSize == 0)
					ForgeHooks.onDestroyCurrentItem(entityplayer,itemstack);
				return true;
		}
	}

	public EntityPlayer createPlayer(World world) {
		return new EntityPlayerSP(mc, world, mc.session,
				world.worldProvider.worldType);
	}

	public void interactWithEntity(EntityPlayer entityplayer, Entity entity) {
		entityplayer.useCurrentItemOnEntity(entity);
	}

	public void attackEntity(EntityPlayer entityplayer, Entity entity) {
		entityplayer.attackTargetEntityWithCurrentItem(entity);
	}

	public ItemStack func_27174_a(int i, int j, int k, boolean flag,
			EntityPlayer entityplayer) {
		return entityplayer.craftingInventory.func_27280_a(j, k, flag,
				entityplayer);
	}

	public void func_20086_a(int i, EntityPlayer entityplayer) {
		entityplayer.craftingInventory.onCraftGuiClosed(entityplayer);
		entityplayer.craftingInventory = entityplayer.inventorySlots;
	}

    public boolean func_35643_e()
    {
        return false;
    }

    public boolean func_35642_f()
    {
        return false;
    }

    public boolean func_35641_g()
    {
        return true;
    }

    public boolean func_35640_h()
    {
        return false;
    }

    public boolean func_35636_i()
    {
        return false;
    }

    public void func_35637_a(ItemStack itemstack, int i)
    {
    }

    public void func_35639_a(ItemStack itemstack)
    {
    }
    
    protected void harvestBlock(Block block, int x, int y, int z, int meta) {
		ItemStack itemstack1 = mc.thePlayer.getCurrentEquippedItem();
		boolean magnetize = itemstack1 != null && itemstack1.getItem().getItemName().toLowerCase().contains("magnet")
						&& ((itemstack1.getItem() != NFC.magnethoe || block instanceof BlockCrops)
						&& (itemstack1.getItem() != NFC.magnetshears || itemstack1.getItem().getStrVsBlock(itemstack1, block) > 1 || block == Block.tallGrass || block == Block.deadBush));
		int[] silkDropAndMeta = mc.getMiddleClickID(mc.theWorld.rand, block.blockID, meta);
		if(!magnetize || block instanceof BlockContainer ||  Minecraft.picksDrop.contains(block) || (magnetize && block.idDropped(meta, mc.theWorld.rand) == silkDropAndMeta[0] && block.getDamageDropped(meta) == silkDropAndMeta[1])) {
            block.harvestBlock(mc.theWorld, mc.thePlayer, x, y, z, meta);
		} else {
			float f = 0.7F;
			double d = (double) (mc.theWorld.rand.nextFloat() * f)+ (double) (1.0F - f) * 0.5D;
			double d1 = (double) (mc.theWorld.rand.nextFloat() * f) + (double) (1.0F - f) * 0.5D;
			double d2 = (double) (mc.theWorld.rand.nextFloat() * f) + (double) (1.0F - f) * 0.5D;
			EntityItem entityitem = new EntityItem(mc.theWorld, (double) x + d,
					(double) y + d1, (double) z + d2, new ItemStack(silkDropAndMeta[0], 1, silkDropAndMeta[1]));
			if(!mc.isMultiplayerWorld())
			{
				mc.theWorld.entityJoinedWorld(entityitem);
			}
		}
		if(magnetize) {
			List<EntityItem> capturedDrops = mc.theWorld.getEntitiesWithinAABB(EntityItem.class, AxisAlignedBB.getBoundingBox(x, y, z, x + 1, y + 1, z + 1));
			for(EntityItem item : capturedDrops) {
				if(item.age == 0) {
					int prevDelay = item.delayBeforeCanPickup;
					item.delayBeforeCanPickup = 0;
					item.onCollideWithPlayer(mc.thePlayer);
					item.delayBeforeCanPickup = prevDelay;
				}
			}
		}
    }
	
	protected final Minecraft mc;
	public boolean isInTestMode;
}
