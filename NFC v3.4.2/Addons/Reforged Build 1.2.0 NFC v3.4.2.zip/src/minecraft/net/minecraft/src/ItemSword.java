// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

// Referenced classes of package net.minecraft.src:
//            Item, EnumToolMaterial, Block, ItemStack, 
//            EntityLiving, Entity

public class ItemSword extends Item {

	public ItemSword(int i, EnumToolMaterial enumtoolmaterial) {
		super(i);
		toolMaterial = enumtoolmaterial;
		maxStackSize = 1;
		int maxUses = enumtoolmaterial.getMaxUses();
		int harvestLevel = Math.min(enumtoolmaterial.getHarvestLevel(), 4);
		if (enumtoolmaterial == EnumToolMaterial.GOLD)
			harvestLevel = 0;
		 else if (enumtoolmaterial == EnumToolMaterial.TUNGSTEN || enumtoolmaterial == EnumToolMaterial.GEM
			|| enumtoolmaterial == EnumToolMaterial.STEEL)
			harvestLevel = 5;
//		setMaxDamage((enumtoolmaterial.getHarvestLevel()+2)*(enumtoolmaterial.getHarvestLevel()+2)*10);
		setMaxDamage(Math.round((maxUses / 6) + ((harvestLevel + 1) * 35)));
		weaponDamage = enumtoolmaterial.getDamageVsEntity();
	}

	public float getStrVsBlock(ItemStack itemstack, Block block) {
		return block.blockID != Block.web.blockID ? 1.5F : 15F;
	}

	public boolean hitEntity(ItemStack itemstack, EntityLiving entityliving,
			EntityLiving entityliving1) {
		if ((!entityliving.isDead && entityliving.hurtTime == 10)) {
			itemstack.damageItem(1, entityliving1);
		}
		return true;
	}

	public boolean onBlockDestroyed(ItemStack itemstack, int i, int j, int k,
			int l, EntityLiving entityliving) {
		itemstack.damageItem(2, entityliving);
		return true;
	}

	public int getDamageVsEntity(Entity entity) {
		return weaponDamage;
	}

	public boolean isFull3D() {
		return true;
	}

	public boolean canHarvestBlock(Block block) {
		return block.blockID == Block.web.blockID;
	}
	
//    public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
//    {
//    	System.out.println(itemstack.getItemName() + " max durability:");
//    	System.out.println(itemstack.getMaxDamage());
//        return itemstack;
//    }

	public int weaponDamage;
	public EnumToolMaterial toolMaterial;
}
