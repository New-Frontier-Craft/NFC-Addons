// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

// Referenced classes of package net.minecraft.src:
//            Block, ItemStack, Item

public class FurnaceRecipes
{

    public static final FurnaceRecipes smelting()
    {
        return smeltingBase;
    }

    private FurnaceRecipes()
    {
        smeltingList = new HashMap();
        metaSmeltingList = new HashMap();
        addSmelting(Block.oreIron.blockID, new ItemStack(Item.ingotIron));
        addSmelting(Block.oreGold.blockID, new ItemStack(Item.ingotGold));
        addSmelting(Block.oreDiamond.blockID, new ItemStack(Item.diamond));
        addSmelting(Block.sand.blockID, new ItemStack(Block.glass));
        addSmelting(Item.porkRaw.shiftedIndex, new ItemStack(Item.porkCooked));
        addSmelting(Item.fishRaw.shiftedIndex, new ItemStack(Item.fishCooked));
        addSmelting(Block.cobblestone.blockID, new ItemStack(Block.stone));
        addSmelting(Item.clay.shiftedIndex, new ItemStack(Item.brick));
        addSmelting(Block.cactus.blockID, new ItemStack(Item.dyePowder, 1, 2));
        addSmelting(Block.wood.blockID, new ItemStack(Item.coal, 1, 1));
        NFC.addSmelting(this);
    }

    @Deprecated
    public ItemStack getSmeltingResult(int i, int j)
    {
        return (ItemStack)smeltingList.get(new StringBuilder().append(Integer.valueOf(i)).append(":")
        		.append(Integer.valueOf(j)).toString());
    }
    
    public void addSmelting(int i, ItemStack itemstack2)
    {
        smeltingList.put(Integer.valueOf(i), itemstack2);
    }
    
    public ItemStack getSmeltingResult(int i)
    {
        return (ItemStack)smeltingList.get(Integer.valueOf(i));
    }
    
    public Map getSmeltingList()
    {
        return smeltingList;
    }

    private static final FurnaceRecipes smeltingBase = new FurnaceRecipes();
    private Map smeltingList;
    private Map metaSmeltingList;


    /**
     * Add a metadata-sensitive furnace recipe
     * @param itemID The Item ID
     * @param metadata The Item Metadata
     * @param itemstack The ItemStack for the result
     */
    public void addSmelting(int itemID, int metadata, ItemStack itemstack)
    {
        metaSmeltingList.put(Arrays.asList(itemID, metadata), itemstack);
    }

    /**
     * Used to get the resulting ItemStack form a source ItemStack
     * @param item The Source ItemStack
     * @return The result ItemStack
     */
    public ItemStack getSmeltingResult(ItemStack item)
    {
        if (item == null)
        {
            return null;
        }
        ItemStack ret = (ItemStack)metaSmeltingList.get(Arrays.asList(item.itemID, item.getItemDamage()));
        if (ret != null)
        {
            return ret;
        }
        return (ItemStack)smeltingList.get(Integer.valueOf(item.itemID));
    }

}
