package net.minecraft.src;

import net.minecraft.src.forge.ForgeHooks;
import net.minecraft.src.forge.MinecraftForge;
import net.minecraft.src.nfcforge.ModLoaderHook;
import net.minecraft.src.reforged.Reforged;
import net.minecraft.src.reforged.ReforgedHooks;

@SuppressWarnings("unused")
public class mod_Reforged extends BaseModMp {
    @Override
    public void ModsLoaded() {
        /* At least init ModLoaderMP... */
        super.ModsLoaded();

        /* TODO: Move this perhaps to the new class, like mod_NFCCompatibility or etc. */
        if(ModLoader.isModLoaded(ModLoaderHook.getClassName("mod_BuildCraftEnergy"))) {
            try {
                Class<?> bc = Class.forName("BuildCraftEnergy");
                ModLoaderHook.registerFluidIntoClass((BlockFluid) bc.getField("oilStill").get(null));
                ModLoaderHook.registerFluidIntoClass((BlockFluid) bc.getField("oilMoving").get(null));

                Item.itemsList[(int) bc.getField("bucketOil").get(null)] = null;
                Item.itemsList[(int) bc.getField("bucketOil").get(null)] = NFC.bucketOil;
            } catch (ClassNotFoundException | NoSuchFieldException | IllegalAccessException e) {
                e.printStackTrace();
            }
        }
    }

    public mod_Reforged() {
        try {
            Block.touch();
            Item.touch();
        } catch (NoSuchMethodError r) {
            if(Reforged.hasIDResolver())
                MinecraftForge.killMinecraft("mod_Reforged", "Please install Reforged after IDResolver!");
            else
                MinecraftForge.killMinecraft("mod_Reforged", "Block or Item was modified. Please fix your installation!");
        }

        try {
            PlayerControllerMP.touch();
            PlayerControllerSP.touch();
        } catch (NoSuchMethodError e) {
            if (Reforged.hasSAPI())
                MinecraftForge.killMinecraft("mod_Reforged", "Please install Reforged after the ForgeSAPI patch and SAPI!");
            else
                MinecraftForge.killMinecraft("mod_Reforged", "PlayerControllers were modified. Please fix your installation!");
        }
    }

    @Override
    public String Version() {
        return String.format("[Forge %d.%d.%d, Reforged %d.%d.%d]",
                ForgeHooks.majorVersion,    	ForgeHooks.minorVersion, 	ForgeHooks.revisionVersion,
                ReforgedHooks.majorVersion,    	ReforgedHooks.minorVersion, ReforgedHooks.revisionVersion
        );
    }
}
