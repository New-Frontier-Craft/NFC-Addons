// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import java.util.ArrayList;
import java.util.List;

// Referenced classes of package net.minecraft.src:
//            Container, Block, ItemStack, Item, 
//            EntityPlayer, Slot, GuiContainerCreative, InventoryBasic

	@SuppressWarnings({ "unchecked", "rawtypes" })
class ContainerCreative extends Container
{

	public ContainerCreative(EntityPlayer entityplayer)
    {
		player = entityplayer;
		search = "";
        field_35375_a = addItems(entityplayer);
        InventoryPlayer inventoryplayer = entityplayer.inventory;
        for(int j2 = 0; j2 < 9; j2++)
        {
            for(int l2 = 0; l2 < 8; l2++)
            {
                addSlot(new Slot(GuiContainerCreative.func_35310_g(), l2 + j2 * 8, 8 + l2 * 18, 18 + j2 * 18));
            }
        }

        for(int k2 = 0; k2 < 9; k2++)
        {
            addSlot(new Slot(inventoryplayer, k2, 8 + k2 * 18, 184));
        }
        func_35374_a(0.0F);
    }
	
	public List addItems(EntityPlayer entityplayer) {
		field_35375_a = new ArrayList();
        for(int k1 = 0; k1 < Block.blocksList.length; k1++)
        {
            if(Block.blocksList[k1] == null
            		|| Block.blocksList[k1] instanceof BlockStepNS || Block.blocksList[k1] instanceof BlockStepEW
            		|| Block.blocksList[k1] == Block.waterStill || Block.blocksList[k1] == Block.lavaStill
            		|| Block.blocksList[k1] == Block.pistonExtension || Block.blocksList[k1] == Block.pistonMoving
            		|| Block.blocksList[k1] == Block.signPost || Block.blocksList[k1] == Block.signWall
            		|| Block.blocksList[k1] == Block.doorSteel || Block.blocksList[k1] == Block.doorWood
            		|| Block.blocksList[k1] == Block.blockBed || Block.blocksList[k1] == Block.crops
            		|| Block.blocksList[k1] == Block.oreRedstoneGlowing || Block.blocksList[k1] == Block.torchRedstoneIdle
            		|| Block.blocksList[k1] == NFC.FakeBedrock || Block.blocksList[k1] == NFC.RecordCrop
            		|| Block.blocksList[k1] == NFC.OilStill || Block.blocksList[k1] == Block.redstoneRepeaterActive
            		|| Block.blocksList[k1] == Block.redstoneRepeaterIdle
            		|| Block.blocksList[k1] == NFC.BrickOvenActive || Block.blocksList[k1] == Block.stoneOvenActive
            		|| Block.blocksList[k1] == NFC.mountainore
            		|| Block.blocksList[k1] == Block.waterMoving || Block.blocksList[k1] == Block.cake
        			|| Block.blocksList[k1] == NFC.Oil || Block.blocksList[k1] == Block.lavaMoving
        			|| Block.blocksList[k1] == Block.fire || Block.blocksList[k1] == Block.redstoneWire
        			|| Block.blocksList[k1] == Block.portal || Block.blocksList[k1] == Block.reed
        			|| Block.blocksList[k1] == Block.tilledField)
            	continue;
            
            	if(k1 == Block.tallGrass.blockID) {
                    addToSlot(new ItemStack(NFC.tallgrassitem.shiftedIndex, 1, 1));
                    addToSlot(new ItemStack(NFC.tallgrassitem.shiftedIndex, 1, 2));
            	} else if(k1 == Block.cloth.blockID || k1 == Block.lockedChest.blockID
            			|| k1 == NFC.dyedPlanks.blockID) {
                    for(int l1 = 0; l1 < 16; l1++) {
                    	if(k1 == Block.cloth.blockID)
                        addToSlot(new ItemStack(Block.cloth.blockID, 1, l1));
                    	else if(k1 == Block.lockedChest.blockID)
                        addToSlot(new ItemStack(Block.lockedChest.blockID, 1, l1));
                    	else if(k1 == NFC.dyedPlanks.blockID)
                        addToSlot(new ItemStack(NFC.dyedPlanks.blockID, 1, l1));
                    }
            	} else if(k1 == Block.stairSingle.blockID) {
                    for(int l1 = 0; l1 < 5; l1++) {
                		addToSlot(new ItemStack(Block.stairSingle, 1, l1));
                    }
            	} else if(k1 == Block.wood.blockID) {
                    for(int l1 = 0; l1 < 3; l1++) {
                		addToSlot(new ItemStack(Block.wood, 1, l1));
                    }
            	} else if(k1 == Block.leaves.blockID) {
                    for(int l1 = 0; l1 < 4; l1++) {
                		addToSlot(new ItemStack(Block.leaves, 1, l1));
                    }
            	} else if(k1 == NFC.biolumMushroom.blockID) {
                    addToSlot(new ItemStack(NFC.biolumMushroom.blockID, 1, 0));
                    addToSlot(new ItemStack(NFC.biolumMushroom.blockID, 1, 1));
            	} else if(k1 == Block.sapling.blockID) {
                    for(int l1 = 0; l1 < 4; l1++) {
                		addToSlot(new ItemStack(Block.sapling, 1, l1));
                    }
            	} else if(k1 == Block.glass.blockID) {
                    for(int l1 = 0; l1 < 4; l1++) {
                		addToSlot(new ItemStack(Block.glass, 1, l1));
                    }
            	} else if(k1 == NFC.cobbleWall.blockID) {
            		addToSlot(new ItemStack(NFC.cobbleWall, 1, 0));
            		addToSlot(new ItemStack(NFC.cobbleWall, 1, 1));
            	} else if(k1 == Block.brick.blockID) {
            		addToSlot(new ItemStack(Block.brick, 1, 0));
            		addToSlot(new ItemStack(Block.brick, 1, 1));
            	} else if(k1 == NFC.stoneBlock.blockID) {
            		addToSlot(new ItemStack(NFC.stoneBlock, 1, 0));
            		addToSlot(new ItemStack(NFC.stoneBlock, 1, 1));
            	} else if(k1 == NFC.stoneBlockoffxy.blockID) {
            		addToSlot(new ItemStack(NFC.stoneBlockoffxy, 1, 0));
            		addToSlot(new ItemStack(NFC.stoneBlockoffxy, 1, 1));
            	} else if(k1 == NFC.stoneBlockoffy.blockID) {
            		addToSlot(new ItemStack(NFC.stoneBlockoffy, 1, 0));
            		addToSlot(new ItemStack(NFC.stoneBlockoffy, 1, 1));
            	} else if(k1 == NFC.stoneBlockoffx.blockID) {
            		addToSlot(new ItemStack(NFC.stoneBlockoffx, 1, 0));
            		addToSlot(new ItemStack(NFC.stoneBlockoffx, 1, 1));
            	} else if(k1 == NFC.stoneBlockSmall.blockID) {
            		addToSlot(new ItemStack(NFC.stoneBlockSmall, 1, 0));
            		addToSlot(new ItemStack(NFC.stoneBlockSmall, 1, 1));
            	} else if(k1 == NFC.stoneBricks.blockID) {
            		addToSlot(new ItemStack(NFC.stoneBricks, 1, 0));
            		addToSlot(new ItemStack(NFC.stoneBricks, 1, 1));
            	} else if(k1 == NFC.barrier.blockID) {
                    addToSlot(new ItemStack(NFC.barrier, 1, 0));
                    addToSlot(new ItemStack(NFC.barrier, 1, 1));
            	} else
            		addToSlot(new ItemStack(Block.blocksList[k1]));
        }
		addToSlot(new ItemStack(Block.waterMoving));
		addToSlot(new ItemStack(NFC.Oil));
		addToSlot(new ItemStack(Block.lavaMoving));
		addToSlot(new ItemStack(Block.fire));
		addToSlot(new ItemStack(Block.portal));
		addToSlot(new ItemStack(Block.tilledField));
        
        for(int k1 = 256; k1 < Item.itemsList.length; k1++)
        {
            if(Item.itemsList[k1] == null
            		|| Item.itemsList[k1] == NFC.writtenBook || Item.itemsList[k1] == NFC.tallgrassitem
            		|| Item.itemsList[k1] == NFC.fakecobbleitem1 || Item.itemsList[k1] == NFC.fakecobbleitem2
            		|| Item.itemsList[k1] == NFC.fakecobbleitem3 || Item.itemsList[k1] == NFC.record26
            		|| Item.itemsList[k1] == NFC.recordchant || Item.itemsList[k1] == NFC.recorddroopylikesyourface
            		|| Item.itemsList[k1] == NFC.recordilackanemotion || Item.itemsList[k1] == NFC.recordinberlinpeopleactdifferently
            		|| Item.itemsList[k1] == NFC.recordpleasedo || Item.itemsList[k1] == NFC.recordseaweed
            		|| Item.itemsList[k1] == NFC.record18
            		|| Item.itemsList[k1] == Item.mapItem || Item.itemsList[k1] == NFC.coloredseeds)
            	continue;
            
            	if(k1 == Item.dyePowder.shiftedIndex) {
                    for(int l1 = 0; l1 < 16; l1++)
                    {
                        addToSlot(new ItemStack(Item.dyePowder.shiftedIndex, 1, l1));
                    }
            	} else if(k1 == Item.coal.shiftedIndex) {
                    addToSlot(new ItemStack(Item.coal.shiftedIndex, 1, 0));
                    addToSlot(new ItemStack(Item.coal.shiftedIndex, 1, 1));
            	} else if(k1 == NFC.spawnegg.shiftedIndex) {
//            		for(int i = 1; i < 128; i++) {
//            			if (EntityList.getClassFromID(i) != null && !EntityList.getClassFromID(i).getClass().isInstance(EntityLiving.class))
//                            addToSlot(new ItemStack(NFC.spawnegg.shiftedIndex, 1, i));
            		for(int i = 1; i < ItemEggMonster.eggMobs.length; i++) {
                        addToSlot(new ItemStack(NFC.spawnegg.shiftedIndex, 1, ItemEggMonster.eggMobs[i]));
            		}
            	} else
                    addToSlot(new ItemStack(Item.itemsList[k1]));
        }

        return field_35375_a;
	}
	
	public void updateSlots(String searchText) {
		field_35375_a.clear();
		search = NFC.removeAccents(searchText);
		addItems(player);
	}
	
	public void addToSlot(ItemStack itemstack) {
		String name = StatCollector.translateToLocal(itemstack.getItem().getItemNameIS(itemstack) + ".name").toLowerCase();
		name = NFC.removeAccents(name);
		if(search.equals("") || name.contains(search.toLowerCase())) {
			field_35375_a.add(itemstack);
		}
		else return;
	}
    
    public void putStackInSlot(int i, ItemStack itemstack)
    {
    	if (i > 8)
        	getSlot(i).putStack(itemstack);
    	
    	if (player.worldObj.multiplayerWorld) {
    		player.inventorySlots.getSlot(i).putStack(itemstack);
            func_35374_a(player.creativeScroll);
    	}
    }
    
    public void func_35374_a(float f)
    {
        int i = (field_35375_a.size() / 8 - 8) + 1;
        int j = (int)((double)(f * (float)i) + 0.5D);
        if(j < 0)
        {
            j = 0;
        }
        for(int k = 0; k < 9; k++)
        {
            for(int l = 0; l < 8; l++)
            {
                int i1 = l + (k + j) * 8;
                if(i1 >= 0 && i1 < field_35375_a.size())
                {
                    GuiContainerCreative.func_35310_g().setInventorySlotContents(l + k * 8, (ItemStack)field_35375_a.get(i1));
                } else
                {
                    GuiContainerCreative.func_35310_g().setInventorySlotContents(l + k * 8, null);
                }
            }

        }

    }

    protected void func_35373_b(int i, int j, boolean flag, EntityPlayer entityplayer)
    {
    }

	public boolean isUsableByPlayer(EntityPlayer entityplayer) {
		return true;
	}
	
    public List field_35375_a;
    private EntityPlayer player;
    String search;

}
