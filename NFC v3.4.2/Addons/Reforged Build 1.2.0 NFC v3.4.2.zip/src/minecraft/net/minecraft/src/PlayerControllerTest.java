// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import java.util.List;
import java.util.Random;

import net.minecraft.client.Minecraft;

import net.minecraft.src.reforged.Reforged;

// Referenced classes of package net.minecraft.src:
//            PlayerController, EntityPlayer, PlayerCapabilities, InventoryPlayer, 
//            ItemStack, Session, Block, World

public class PlayerControllerTest extends PlayerController
{

    public PlayerControllerTest(Minecraft minecraft)
    {
        super(minecraft);
    }

    public void updateController()
    {
    	Random l = new Random();
    	if (l.nextInt(2) == 0)
            mc.sndManager.playRandomMusicIfReady();
    	else
    		mc.sndManager.playRandomCreativeMusicIfReady();
    }

    public static void func_35646_d(EntityPlayer entityplayer)
    {
        entityplayer.playerCapabilities.gameType = true;
        entityplayer.playerCapabilities.canFly = true;
        entityplayer.playerCapabilities.invulnerable = true;
    }

    public static void func_35645_e(EntityPlayer entityplayer)
    {
        entityplayer.playerCapabilities.gameType = false;
        entityplayer.playerCapabilities.flying = false;
        entityplayer.playerCapabilities.canFly = false;
        entityplayer.playerCapabilities.invulnerable = false;
    }

    public void func_6473_b(EntityPlayer entityplayer)
    {
        func_35646_d(entityplayer);
    }

    public static void func_35644_a(Minecraft minecraft, PlayerController playercontroller, int i, int j, int k, int l)
    {
        minecraft.theWorld.onBlockHit(minecraft.thePlayer, i, j, k, l);
    }

    public boolean sendPlaceBlock(EntityPlayer entityplayer, World world, ItemStack itemstack, int i, int j, int k, int l)
    {
        int i1 = world.getBlockId(i, j, k);
		boolean sneak = entityplayer.isSneaking();
		boolean flag;

        int j1 = 0;
        int k1 = 0;
        
		if(itemstack != null) {
			j1 = itemstack.getItemDamage();
			k1 = itemstack.stackSize;
		}
		
		if (sneak && itemstack != null) {
			if (itemstack.useItem(entityplayer, world, i, j, k, l)) {
		        itemstack.setItemDamage(j1);
		        itemstack.stackSize = k1;
				return true;
			}
			flag = Block.blocksList[i1].blockActivated(world, i, j, k, entityplayer);
	        itemstack.setItemDamage(j1);
	        itemstack.stackSize = k1;
			return flag;
		} else
			if (i1 > 0 && Block.blocksList[i1].blockActivated(world, i, j, k, entityplayer)) {
				if(itemstack != null) {
			        itemstack.setItemDamage(j1);
			        itemstack.stackSize = k1;
				}
				return true;
		} else
			if (itemstack == null) {
				return false;
			} else {
				flag = itemstack.useItem(entityplayer, world, i, j, k, l);
		        itemstack.setItemDamage(j1);
		        itemstack.stackSize = k1;
				return flag;
		}
    }

    public void clickBlock(int i, int j, int k, int l)
    {
        if (canBreakBlock(i, j, k, l)) {
            super.sendBlockRemoved(i, j, k, l);
        }
        func_35644_a(mc, this, i, j, k, l);
        field_35647_c = 10;
    }

    public void sendBlockRemoving(int i, int j, int k, int l)
    {
        field_35647_c--;
        if(field_35647_c <= 0)
        {
            field_35647_c = 10;
            this.clickBlock(i, j, k, l);
        }
    }
    
    public boolean canBreakBlock(int i, int j, int k, int l) {

    	ItemStack istack = mc.thePlayer.getCurrentEquippedItem();
    	Item item;
    	
		int i1 = i;
		int j1 = j;
		int k1 = k;
		
        if(l == 0)
        {
            j1--;
        }
        if(l == 1)
        {
            j1++;
        }
        if(l == 2)
        {
            k1--;
        }
        if(l == 3)
        {
            k1++;
        }
        if(l == 4)
        {
            i1--;
        }
        if(l == 5)
        {
            i1++;
        }

    	boolean flag = true;
    	if (istack != null) {
    		item = istack.getItem();
        	if (item instanceof ItemSword) {
        		flag = false;
        	}
    	}
    	
    	if(mc.theWorld.getBlockId(i1, j1, k1) == 51) {
    		flag = false;
    	}
    	return flag;
    }

    public void resetBlockRemoving()
    {
    }

    public boolean shouldDrawHUD()
    {
        return false;
    }

    public void func_717_a(World world)
    {
        super.func_717_a(world);
    }

    public float getBlockReachDistance() {
        return 5F;
    }

    public boolean func_35641_g()
    {
        return false;
    }

    public boolean func_35640_h()
    {
        return true;
    }

    public boolean func_35636_i()
    {
        return true;
    }

    private int field_35647_c;
}
