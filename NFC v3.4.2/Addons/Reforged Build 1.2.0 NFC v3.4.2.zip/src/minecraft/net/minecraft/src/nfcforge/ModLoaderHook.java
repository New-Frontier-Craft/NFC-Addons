package net.minecraft.src.nfcforge;

import net.minecraft.src.BlockFluid;
import net.minecraft.src.IBlockAccess;
import net.minecraft.src.Vec3D;
import sun.misc.Unsafe;

import java.lang.invoke.MethodHandles;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Collection of several tools and hooks to make ForgeAPI + NFC experience more faithfully.
 */
public class ModLoaderHook {

    public static String getClassName(String s) {
        if(isSandboxMode)
            return "net.minecraft.src." + s;
        return s;
    }

    public static void registerModLocalization(String s, String s1) {
        if(modlocals.containsKey(s))
            System.out.println("A mod has overridden value [" + s + "]! If it's not intended, then you should be concerned...");
        modlocals.put(s, s1);
    }

    public static void loadModLocals(Properties properties) {
        properties.putAll(modlocals);
    }

    /**
     * Registers a fluid block as block with fluid data for Vec3D stuff. Should be used.
     * @param block BlockFluid instance.
     */
    public static void registerFluidIntoClass(BlockFluid block) {
        fluidData.put(block.blockID, block);
    }

    public static Vec3D getFluidInfo(int blockID, IBlockAccess iblockaccess, int i, int j, int k) {
        if(!fluidData.containsKey(blockID))
            return null;
        return fluidData.get(blockID).getFlowVector(iblockaccess, i, j, k);
    }

    private static final Map<Integer, BlockFluid> fluidData = new HashMap<>();
    private static final Map<String, String> modlocals = new HashMap<>();
    public static final boolean isSandboxMode;
    public static Unsafe unsafeInstance;
    public static MethodHandles.Lookup implLookupInstance;

    static {

        /*
         * A better (kinda dirty) replacement for java.lang.reflect, I guess???
         * Getting the lowest access level possible.
         * Useful for hijacking into internals and protected fields/methods.
         */
        try {
            Field f = Unsafe.class.getDeclaredField("theUnsafe");
            f.setAccessible(true);
            unsafeInstance = (Unsafe) f.get(null);
            if(unsafeInstance == null)
                System.out.println("Warning! Couldn't find \"unsafe\" instance! Seems like strange JVM/Java Environment.");
            Field a = MethodHandles.Lookup.class.getDeclaredField("IMPL_LOOKUP");
            implLookupInstance = (MethodHandles.Lookup) unsafeInstance.getObject(unsafeInstance.staticFieldBase(a), unsafeInstance.staticFieldOffset(a));
            if(implLookupInstance == null)
                System.out.println("Warning! Couldn't find \"implLookupInstance\" instance! Seems like strange JVM/Java Environment.");
        } catch (NoSuchFieldException | IllegalAccessException exp) {
            exp.printStackTrace();
        }

        /* Basically checks if ModLoader class is located in "net.minecraft.src" package. */
        boolean a;
        try {
            Class.forName("net.minecraft.src.ModLoader");
            a = true;
        } catch (ClassNotFoundException e) {
            a = false;
        }
        isSandboxMode = a;
    }
}
