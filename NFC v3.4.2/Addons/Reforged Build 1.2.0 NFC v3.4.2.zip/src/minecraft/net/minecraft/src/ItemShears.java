// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;


// Referenced classes of package net.minecraft.src:
//            Item, Block, BlockLeaves, ItemStack, 
//            EntityLiving

import net.minecraft.src.forge.IShearable;

import java.util.ArrayList;

public class ItemShears extends Item
{

    public ItemShears(int i)
    {
        super(i);
        setMaxStackSize(1);
        setMaxDamage(238);
    }

    public boolean onBlockDestroyed(ItemStack itemstack, int i, int j, int k, int l, EntityLiving entityliving)
    {
        if(getStrVsBlock(itemstack, Block.blocksList[i]) > 1 || i == Block.tallGrass.blockID || i == Block.deadBush.blockID)
        {
            itemstack.damageItem(1, entityliving);
        }
        return super.onBlockDestroyed(itemstack, i, j, k, l, entityliving);
    }

    public boolean canHarvestBlock(Block block)
    {
        return block.blockID == Block.web.blockID;
    }

    public float getStrVsBlock(ItemStack itemstack, Block block)
    {
        if(block.blockID == Block.web.blockID || block.blockID == Block.leaves.blockID)
        {
            return 15F;
        }
        if(block.blockID == Block.cloth.blockID)
        {
            return 5F;
        } else
        {
            return super.getStrVsBlock(itemstack, block);
        }
    }

    @Override
    public void saddleEntity(ItemStack itemstack, EntityLiving entity)
    {
        if (entity.worldObj.multiplayerWorld)
        {
            return;
        }
        if (entity instanceof IShearable)
        {
            IShearable target = (IShearable)entity;
            if (target.isShearable(itemstack, entity.worldObj, (int)entity.posX, (int)entity.posY, (int)entity.posZ))
            {
                ArrayList<ItemStack> drops = target.onSheared(itemstack, entity.worldObj, (int)entity.posX, (int)entity.posY, (int)entity.posZ);
                for(ItemStack stack : drops)
                {
                    EntityItem ent = entity.entityDropItem(stack, 1.0F);
                    ent.motionY += entity.rand.nextFloat() * 0.05F;
                    ent.motionX += (entity.rand.nextFloat() - entity.rand.nextFloat()) * 0.1F;
                    ent.motionZ += (entity.rand.nextFloat() - entity.rand.nextFloat()) * 0.1F;
                }
                itemstack.damageItem(1, entity);
            }
        }
    }

    @Override
    public boolean onBlockStartBreak(ItemStack itemstack, int X, int Y, int Z, EntityPlayer player)
    {

        if (player.worldObj.multiplayerWorld)
        {
            return false;
        }

        int id = player.worldObj.getBlockId(X, Y, Z);

        if ((Block.blocksList[id] != null && Block.blocksList[id] instanceof IShearable))
        {
            IShearable target = (IShearable)Block.blocksList[id];
            if (target.isShearable(itemstack, player.worldObj, X, Y, Z))
            {
                ArrayList<ItemStack> drops = target.onSheared(itemstack, player.worldObj, X, Y, Z);
                for(ItemStack stack : drops)
                {
                    float f = 0.7F;
                    double d  = (double)(player.rand.nextFloat() * f) + (double)(1.0F - f) * 0.5D;
                    double d1 = (double)(player.rand.nextFloat() * f) + (double)(1.0F - f) * 0.5D;
                    double d2 = (double)(player.rand.nextFloat() * f) + (double)(1.0F - f) * 0.5D;
                    EntityItem entityitem = new EntityItem(player.worldObj, (double)X + d, (double)Y + d1, (double)Z + d2, stack);
                    entityitem.delayBeforeCanPickup = 10;
                    player.worldObj.entityJoinedWorld(entityitem);
                }
                itemstack.damageItem(1, player);
                player.addStat(StatList.mineBlockStatArray[id], 1);
            }
        }
        return false;
    }
}
